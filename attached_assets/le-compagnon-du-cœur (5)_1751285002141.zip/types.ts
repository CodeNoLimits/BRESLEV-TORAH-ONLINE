
export interface SefariaNode {
  category?: string;
  heCategory?: string;
  title: string;
  heTitle: string;
  ref?: string;
  contents?: SefariaNode[];
  nodes?: SefariaSchemaNode[];
  schema?: {
    nodes: SefariaSchemaNode[];
  };
}

export interface SefariaSchemaNode {
  title: string;
  heTitle: string;
  key: string;
  nodes?: SefariaSchemaNode[];
}

export enum MessageAuthor {
  USER = 'user',
  AI = 'ai',
}

export type MessageStatus = 'loading' | 'done' | 'error';

export interface ChatMessage {
  id: number;
  author: MessageAuthor;
  text: string;
  status: MessageStatus;
}

export type Language = 'fr' | 'en' | 'he';

export enum InputMode {
  QUESTION = 'question',
  SNIPPET = 'snippet',
  GUIDANCE = 'guidance',
}
