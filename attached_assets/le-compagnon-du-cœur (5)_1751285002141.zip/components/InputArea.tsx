
import React, { useState, useRef, useEffect } from 'react';
import { InputMode, Language } from '../types';
import { SendIcon, LightBulbIcon, DocumentTextIcon, ChatBubbleLeftRightIcon } from './icons';
import { UI_TEXTS } from '../constants';

interface InputAreaProps {
  onSendMessage: (text: string, mode: InputMode) => void;
  isSending: boolean;
  language: Language;
}

const TabButton: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-t-lg border-b-2 transition-all
      ${isActive
        ? 'text-sky-300 border-sky-400'
        : 'text-slate-400 border-transparent hover:text-white hover:bg-slate-700/50'
      }`}
  >
    {icon}
    {label}
  </button>
);

export const InputArea: React.FC<InputAreaProps> = ({ onSendMessage, isSending, language }) => {
  const [text, setText] = useState('');
  const [mode, setMode] = useState<InputMode>(InputMode.QUESTION);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [text]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isSending) {
      onSendMessage(text.trim(), mode);
      setText('');
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e as any);
    }
  }

  const getPlaceholder = () => {
    switch(mode) {
      case InputMode.GUIDANCE:
        return UI_TEXTS[language].guidancePlaceholder;
      default:
        return UI_TEXTS[language].inputPlaceholder;
    }
  }

  return (
    <div className="px-6 pb-4 pt-2 border-t border-slate-700/50 bg-slate-850">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center border-b border-slate-700/50 mb-2">
            <TabButton 
                icon={<ChatBubbleLeftRightIcon className="w-5 h-5" />}
                label={UI_TEXTS[language].questionTab}
                isActive={mode === InputMode.QUESTION}
                onClick={() => setMode(InputMode.QUESTION)}
            />
            <TabButton 
                icon={<DocumentTextIcon className="w-5 h-5" />}
                label={UI_TEXTS[language].snippetTab}
                isActive={mode === InputMode.SNIPPET}
                onClick={() => setMode(InputMode.SNIPPET)}
            />
             <TabButton 
                icon={<LightBulbIcon className="w-5 h-5" />}
                label={UI_TEXTS[language].guidanceTab}
                isActive={mode === InputMode.GUIDANCE}
                onClick={() => setMode(InputMode.GUIDANCE)}
            />
        </div>
        <form onSubmit={handleSubmit} className="relative">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={getPlaceholder()}
            rows={1}
            disabled={isSending}
            className="w-full bg-slate-800 border border-slate-600 rounded-2xl py-3 pl-4 pr-14 resize-none text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-all max-h-48"
          />
          <button
            type="submit"
            disabled={isSending || !text.trim()}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-sky-600 text-white hover:bg-sky-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
          >
            <SendIcon className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
