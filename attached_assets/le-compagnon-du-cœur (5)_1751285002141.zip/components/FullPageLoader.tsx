
import React from 'react';
import { SparklesIcon } from './icons';

interface FullPageLoaderProps {
    message?: string | null;
}

export const FullPageLoader: React.FC<FullPageLoaderProps> = ({ message }) => {
    return (
        <div className="fixed inset-0 bg-slate-900 flex flex-col items-center justify-center text-slate-300">
            <SparklesIcon className="w-16 h-16 text-sky-500 animate-pulse" />
            <h1 className="mt-4 text-2xl font-poppins font-bold">Le Compagnon du Cœur</h1>
            {message ? (
                 <p className="mt-4 text-center max-w-md bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg">{message}</p>
            ) : (
                <p className="mt-2">Chargement des enseignements...</p>
            )}
        </div>
    );
};
