
import React, { useState } from 'react';
import { SefariaNode } from '../types';
import { ChevronRightIcon, BookOpenIcon, DotIcon } from './icons';
import { UI_TEXTS } from '../constants';
import { Language } from '../types';


interface TreeNodeProps {
  node: SefariaNode;
  onSelectRef: (ref: string, title: string) => void;
  level: number;
  activeRef: string | null;
  language: Language;
}

const TreeNode: React.FC<TreeNodeProps> = ({ node, onSelectRef, level, activeRef, language }) => {
  const [isOpen, setIsOpen] = useState(level < 1);
  const title = language === 'he' && node.heTitle ? node.heTitle : node.title;
  const hasChildren = node.contents && node.contents.length > 0;
  
  // A node is a fetchable text ONLY if it's a leaf node (no children) and has a ref.
  const isTextNode = !hasChildren && !!node.ref;

  // Handles clicks on the entire node item.
  const handleInteraction = () => {
    if (isTextNode) {
      // If it's a text node, select it to fetch its content.
      onSelectRef(node.ref!, title);
    } else if (hasChildren) {
      // If it's a container node, simply toggle its open/closed state.
      setIsOpen(!isOpen);
    }
    // If it's a leaf node without a ref (a category placeholder), do nothing.
  };

  const liClassName = `
    flex items-center text-sm rounded-md transition-colors
    ${(isTextNode || hasChildren) ? 'cursor-pointer' : 'cursor-default'}
    ${isTextNode ? 'hover:bg-slate-700' : ''}
    ${activeRef === node.ref && isTextNode ? 'bg-sky-800 text-white' : 'text-slate-300'}
  `;

  return (
    <li className={language === 'he' ? 'rtl' : 'ltr'}>
      <div 
        onClick={handleInteraction} 
        className={liClassName} 
        style={{ paddingLeft: `${level * 0.75}rem` }}
        role="button"
        tabIndex={isTextNode || hasChildren ? 0 : -1}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleInteraction(); }}
        aria-expanded={hasChildren ? isOpen : undefined}
      >
        <div className="flex items-center py-2 min-w-0 flex-1 pointer-events-none">
          <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
            {hasChildren ? (
              <ChevronRightIcon className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
            ) : (
              isTextNode ? 
              <BookOpenIcon className="w-4 h-4 text-sky-400" /> :
              <DotIcon className="w-4 h-4 text-slate-500" />
            )}
          </div>
          <span className="truncate ml-1">{title}</span>
        </div>
      </div>
      {hasChildren && isOpen && (
        <ul className="pl-4">
          {node.contents?.map((childNode, index) => (
            <TreeNode key={`${childNode.title}-${index}`} node={childNode} onSelectRef={onSelectRef} level={level + 1} activeRef={activeRef} language={language} />
          ))}
        </ul>
      )}
    </li>
  );
};

interface SidebarProps {
  nodes: SefariaNode[] | null;
  onSelectRef: (ref: string, title: string) => void;
  activeRef: string | null;
  language: Language;
}

export const Sidebar: React.FC<SidebarProps> = ({ nodes, onSelectRef, activeRef, language }) => {
  return (
    <aside className="w-80 h-full bg-slate-900 flex-shrink-0 flex flex-col border-r border-slate-700/50">
      <div className={`p-4 border-b border-slate-700/50 ${language === 'he' ? 'text-right' : 'text-left'}`}>
        <h1 className="text-xl font-poppins font-bold text-white">{UI_TEXTS[language].sidebarTitle}</h1>
      </div>
      <div className="overflow-y-auto flex-1 p-2">
        {nodes ? (
          <ul>
            {nodes.map((node, index) => (
              <TreeNode key={`${node.title}-${index}`} node={node} onSelectRef={onSelectRef} level={0} activeRef={activeRef} language={language} />
            ))}
          </ul>
        ) : (
          <div className="p-4 text-center text-slate-400">{UI_TEXTS[language].errorLoadingIndex}</div>
        )}
      </div>
    </aside>
  );
};
