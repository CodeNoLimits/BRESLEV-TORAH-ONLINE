
import React, { useEffect, useRef } from 'react';
import { ChatMessage, MessageAuthor } from '../types';
import { UserIcon, SparklesIcon, RetryIcon, DocumentDuplicateIcon } from './icons';
import { UI_TEXTS } from '../constants';
import { Language } from '../types';
import Markdown from 'react-markdown';

interface ChatBubbleProps {
    message: ChatMessage;
    onSummarize: (text: string) => void;
    onRetry: () => void; // Assuming retry logic is handled by parent
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message, onSummarize, onRetry }) => {
    const isUser = message.author === MessageAuthor.USER;
    const bubbleClass = isUser
        ? 'bg-sky-600/80 self-end'
        : 'bg-slate-700/80 self-start';

    const renderTextWithMarkdown = (text: string) => {
        return (
            <Markdown
                components={{
                    h1: ({node, ...props}) => <h1 className="text-xl font-bold font-poppins my-4" {...props} />,
                    h2: ({node, ...props}) => <h2 className="text-lg font-bold font-poppins my-3" {...props} />,
                    p: ({node, ...props}) => <p className="mb-2" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-disc list-inside mb-2" {...props} />,
                    ol: ({node, ...props}) => <ol className="list-decimal list-inside mb-2" {...props} />,
                    li: ({node, ...props}) => <li className="mb-1" {...props} />,
                    strong: ({node, ...props}) => <strong className="font-bold" {...props} />,
                }}
            >
                {text}
            </Markdown>
        );
    };

    return (
        <div className={`flex items-start gap-3 my-2 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${isUser ? 'bg-sky-500' : 'bg-slate-600'}`}>
                {isUser ? <UserIcon className="w-5 h-5" /> : <SparklesIcon className="w-5 h-5 text-sky-300" />}
            </div>
            <div className={`max-w-2xl w-fit rounded-2xl p-4 text-slate-100 ${bubbleClass}`}>
                {message.status === 'loading' ? (
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                        {message.text && <span className="text-slate-300">{message.text}</span>}
                    </div>
                ) : message.status === 'error' ? (
                    <div className="text-red-400 flex items-center gap-2">
                        <span>{message.text}</span>
                        {/* <button onClick={onRetry} className="p-1 hover:bg-red-500/20 rounded-full"><RetryIcon className="w-4 h-4" /></button> */}
                    </div>
                ) : (
                    renderTextWithMarkdown(message.text)
                )}
                 {!isUser && message.status === 'done' && message.text.length > 500 && (
                    <button 
                        onClick={() => onSummarize(message.text)}
                        className="mt-4 flex items-center gap-2 text-xs text-sky-300 hover:text-sky-200 transition-colors bg-sky-800/50 hover:bg-sky-800/80 px-3 py-1 rounded-full"
                    >
                        <DocumentDuplicateIcon className="w-3 h-3" />
                        {UI_TEXTS['fr'].summarize}
                    </button>
                )}
            </div>
        </div>
    );
};


interface ChatViewProps {
  messages: ChatMessage[];
  onSummarize: (text: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({ messages, onSummarize }) => {
    const endOfMessagesRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    return (
        <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-4xl mx-auto flex flex-col">
                {messages.length === 0 && (
                     <div className="text-center text-slate-400 mt-20">
                        <SparklesIcon className="w-16 h-16 mx-auto text-slate-600" />
                        <h2 className="text-2xl font-poppins font-bold mt-4">Le Compagnon du Cœur</h2>
                        <p className="mt-2">{UI_TEXTS['fr'].welcomeMessage}</p>
                    </div>
                )}
                {messages.map((msg) => (
                    <ChatBubble key={msg.id} message={msg} onSummarize={onSummarize} onRetry={() => {}} />
                ))}
                <div ref={endOfMessagesRef} />
            </div>
        </div>
    );
};
