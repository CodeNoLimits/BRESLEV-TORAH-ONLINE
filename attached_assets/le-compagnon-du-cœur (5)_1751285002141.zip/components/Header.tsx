
import React from 'react';
import { Language } from '../types';

interface HeaderProps {
    language: Language;
    onLanguageChange: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({ language, onLanguageChange }) => {
    const languages: { code: Language; label: string }[] = [
        { code: 'fr', label: 'FR' },
        { code: 'en', label: 'EN' },
        { code: 'he', label: 'HE' },
    ];

    return (
        <header className="h-16 flex-shrink-0 border-b border-slate-700/50 flex items-center justify-end px-6">
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg">
                {languages.map(lang => (
                    <button
                        key={lang.code}
                        onClick={() => onLanguageChange(lang.code)}
                        className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                            language === lang.code 
                                ? 'bg-sky-600 text-white' 
                                : 'text-slate-300 hover:bg-slate-700'
                        }`}
                    >
                        {lang.label}
                    </button>
                ))}
            </div>
        </header>
    );
};
