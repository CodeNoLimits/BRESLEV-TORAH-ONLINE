import { SEFARIA_API_BASE } from '../constants';
import { SefariaNode, SefariaSchemaNode, Language } from '../types';

const CACHE_KEY = 'sefariaBreslovIndex';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

const BRESLOV_BOOKS = [
  'Likutei_Moharan',
  'Likutei_Halakhot',
  'Likutei_Tefilot',
  'Likkutei_Etzot',
  'Sefer_HaMiddot',
  'Sichot_HaRan',
  'Chayei_Moharan',
  'Shivchei_HaRan',
  'Sippurei_Maasiyot',
];

// Recursively transforms Sefaria's schema structure into our SefariaNode structure.
const transformSchemaNodes = (nodes: SefariaSchemaNode[]): SefariaNode[] => {
    return nodes.map(node => ({
        title: node.title,
        heTitle: node.heTitle,
        // In a schema, the 'key' property holds the correct, unique reference (Ref).
        ref: node.key,
        // Recursively transform child nodes if they exist.
        contents: node.nodes ? transformSchemaNodes(node.nodes) : undefined,
    }));
};

// Transforms the entire index response for a single book into a SefariaNode.
const transformBookIndexToSefariaNode = (bookIndex: any): SefariaNode => {
    // The top-level SefariaNode for a book.
    const rootNode: SefariaNode = {
        title: bookIndex.title,
        heTitle: bookIndex.heTitle,
        // The root itself might not be fetchable, so its ref is less critical.
        // We use its title as a fallback ref, though it's mainly a container.
        ref: bookIndex.title.replace(/ /g, '_'), 
        // The detailed table of contents is in `schema.nodes`. We transform it here.
        contents: bookIndex.schema?.nodes ? transformSchemaNodes(bookIndex.schema.nodes) : undefined,
    };
    return rootNode;
};


export const fetchSefariaIndex = async (): Promise<SefariaNode[]> => {
    const cachedData = sessionStorage.getItem(CACHE_KEY);
    if (cachedData) {
        const { timestamp, data } = JSON.parse(cachedData);
        if (Date.now() - timestamp < CACHE_DURATION) {
            return data;
        }
    }
    
    // Fetch the detailed index for each of the 9 Breslov books in parallel.
    // This is more reliable than the global index.
    const bookPromises = BRESLOV_BOOKS.map(bookRef =>
        fetch(`${SEFARIA_API_BASE}/index/${bookRef}`).then(res => {
            if (!res.ok) {
                console.error(`Failed to fetch index for ${bookRef}`);
                // Return null to handle failure gracefully in Promise.all
                return null;
            }
            return res.json();
        })
    );

    const bookIndices = await Promise.all(bookPromises);

    // Transform each valid book index into our SefariaNode structure.
    const allNodes = bookIndices
        .filter(index => index !== null) // Filter out any failed requests
        .map(transformBookIndexToSefariaNode);

    if (allNodes.length === 0) {
        throw new Error("Failed to fetch any Breslov book indices from Sefaria.");
    }

    sessionStorage.setItem(CACHE_KEY, JSON.stringify({ timestamp: Date.now(), data: allNodes }));
    
    return allNodes;
};

// Utility to strip HTML tags from text
const stripHtml = (html: string) => html.replace(/<[^>]*>?/gm, '');

export const fetchSefariaText = async (ref: string, lang: Language): Promise<{ text: string[], he: string[], ref: string }> => {
    // Strategy: Try v3 API first, as it can be more comprehensive. Fallback to v1 if it fails.

    // 1. Try Sefaria v3 API endpoint
    const v3Url = `${SEFARIA_API_BASE}/v3/texts/${encodeURIComponent(ref)}?lang=${lang}&wrapLinks=false&commentary=0`;
    try {
        const response = await fetch(v3Url);
        if (response.ok) {
            const data = await response.json();
            // v3 has a `versions` array. With the `lang` param, the first version should be the correct one.
            if (data.versions && data.versions.length > 0) {
                const textArray = (data.versions[0]?.text || []).map(stripHtml);
                const heTextArray = (data.he || []).map(stripHtml);
                
                return {
                    text: textArray,
                    he: heTextArray,
                    ref: data.ref,
                };
            }
        }
    } catch (e) {
        console.warn(`Sefaria v3 API failed for ref: ${ref}, falling back to v1.`, e);
    }
    
    // 2. Fallback to Sefaria v1 API endpoint
    const v1Url = `${SEFARIA_API_BASE}/texts/${encodeURIComponent(ref)}?context=1&commentary=0&lang=${lang}`;
    try {
        const response = await fetch(v1Url);
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Failed to fetch text for ref: ${ref}`);
        }
        const data = await response.json();
        
        // Ensure text and he are always arrays of strings and clean them of any HTML.
        const text = (Array.isArray(data.text) ? data.text : [data.text].filter(Boolean)).map(stripHtml);
        const he = (Array.isArray(data.he) ? data.he : [data.he].filter(Boolean)).map(stripHtml);

        return {
            text,
            he,
            ref: data.ref,
        };
    } catch (e) {
         console.error(`Sefaria v1 API also failed for ref: ${ref}.`, e);
         throw e; // Rethrow the final error if both fail
    }
};