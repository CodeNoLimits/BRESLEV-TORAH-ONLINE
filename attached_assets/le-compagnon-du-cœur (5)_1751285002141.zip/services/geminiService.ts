
import { GoogleGenAI, Chat } from '@google/genai';
import { getSystemPrompt } from '../constants';
import { Language } from '../types';

class GeminiService {
  private ai: GoogleGenAI | null = null;
  private systemPrompt: string = '';

  public initialize(language: Language) {
    if (!process.env.API_KEY) {
      throw new Error("API key for Gemini is not set in environment variables.");
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    this.systemPrompt = getSystemPrompt(language);
  }

  public startChat(): Chat {
    if (!this.ai) {
      throw new Error("Gemini service not initialized. Call initialize() first.");
    }
    return this.ai.chats.create({
        model: 'gemini-2.5-flash-preview-04-17',
        config: {
            systemInstruction: this.systemPrompt,
        }
    });
  }
}

export const geminiService = new GeminiService();
