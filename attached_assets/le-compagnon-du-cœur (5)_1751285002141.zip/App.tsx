
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatView } from './components/ChatView';
import { InputArea } from './components/InputArea';
import { Header } from './components/Header';
import { FullPageLoader } from './components/FullPageLoader';
import { fetchSefariaIndex, fetchSefariaText } from './services/sefariaService';
import { geminiService } from './services/geminiService';
import { SefariaNode, ChatMessage, MessageAuthor, Language, InputMode, MessageStatus } from './types';

const App: React.FC = () => {
  const [sefariaTree, setSefariaTree] = useState<SefariaNode[] | null>(null);
  const [isLoadingIndex, setIsLoadingIndex] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language>('fr');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [activeRef, setActiveRef] = useState<string | null>(null);
  const chatRef = useRef<any>(null);

  useEffect(() => {
    const initApp = async () => {
      try {
        if (!process.env.API_KEY) {
            setError("La clé API Gemini n'est pas configurée. Veuillez l'ajouter dans les secrets de l'application.");
            setIsLoadingIndex(false);
            return;
        }
        geminiService.initialize(language);
        chatRef.current = geminiService.startChat();

        const breslovTree = await fetchSefariaIndex();
        setSefariaTree(breslovTree);
      } catch (e) {
        console.error(e);
        setError("Impossible de charger l'index des textes de Sefaria. Veuillez vérifier votre connexion et réessayer.");
      } finally {
        setIsLoadingIndex(false);
      }
    };
    initApp();
  }, [language]);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    setMessages([]);
    setIsLoadingIndex(true);
    setError(null);
    // The useEffect with dependency on `language` will re-initialize the app
  };

  const streamMessage = useCallback(async (prompt: string) => {
    setIsSending(true);
    const messageId = Date.now();
    setMessages(prev => [...prev, { id: messageId, author: MessageAuthor.AI, text: '', status: 'loading' }]);

    try {
        const stream = await chatRef.current.sendMessageStream({ message: prompt });
        let fullResponse = '';
        for await (const chunk of stream) {
            fullResponse += chunk.text;
            setMessages(prev => prev.map(msg => msg.id === messageId ? { ...msg, text: fullResponse, status: 'done' } : msg));
        }
    } catch (e) {
        console.error("Gemini Error:", e);
        setMessages(prev => prev.map(msg => msg.id === messageId ? { ...msg, text: "Une erreur est survenue lors de la communication avec l'IA. Veuillez réessayer.", status: 'error' } : msg));
    } finally {
        setIsSending(false);
    }
  }, []);

  const handleSelectRef = useCallback(async (ref: string, title: string) => {
    setActiveRef(ref);
    const userMessage: ChatMessage = { id: Date.now(), author: MessageAuthor.USER, text: `Analyse du texte : "${title}"`, status: 'done' };
    setMessages([userMessage]);

    setIsSending(true);
    const loadingMessageId = Date.now() + 1;
    setMessages(prev => [...prev, { id: loadingMessageId, author: MessageAuthor.AI, text: `Chargement du texte "${title}"...`, status: 'loading' }]);

    try {
        const { text, he } = await fetchSefariaText(ref, language);
        const fullText = language === 'he' ? he.join('\n') : text.join('\n');
        
        setMessages(prev => prev.map(msg => msg.id === loadingMessageId ? { ...msg, text: `Texte chargé. Analyse en cours...` } : msg));
        
        const prompt = `MODE: ANALYSE_TEXTE\nLANGUE: ${language.toUpperCase()}\n\nAnalyse en profondeur l'enseignement suivant tiré de "${title}" (ref: ${ref}). Voici le texte:\n\n---\n${fullText}\n---`;
        await streamMessage(prompt);

    } catch (e) {
        console.error("Sefaria fetch error:", e);
        const errorText = "Impossible de récupérer ce texte depuis Sefaria. Il est peut-être indisponible ou une erreur réseau est survenue.";
        setMessages(prev => prev.map(msg => msg.id === loadingMessageId ? { ...msg, text: errorText, status: 'error' } : msg));
        setIsSending(false);
    }
  }, [language, streamMessage]);

  const handleSendMessage = useCallback(async (text: string, mode: InputMode) => {
    const userMessage: ChatMessage = { id: Date.now(), author: MessageAuthor.USER, text: text, status: 'done' };
    setMessages(prev => [...prev, userMessage]);

    let prompt = '';
    switch (mode) {
        case InputMode.QUESTION:
            prompt = `MODE: QUESTION_LIBRE\nLANGUE: ${language.toUpperCase()}\n\nQuestion: ${text}`;
            break;
        case InputMode.SNIPPET:
            prompt = `MODE: ANALYSE_EXTRAIT\nLANGUE: ${language.toUpperCase()}\n\nExtrait à analyser: ${text}`;
            break;
        case InputMode.GUIDANCE:
            prompt = `MODE: CONSEIL_SPIRITUEL\nLANGUE: ${language.toUpperCase()}\n\nDemande de conseil: ${text}`;
            break;
    }
    await streamMessage(prompt);
  }, [language, streamMessage]);
  
  const handleSummarize = useCallback(async (textToSummarize: string) => {
    const userMessage: ChatMessage = { id: Date.now(), author: MessageAuthor.USER, text: "Peux-tu résumer ta réponse précédente ?", status: 'done' };
    setMessages(prev => [...prev, userMessage]);
    
    const prompt = `MODE: RÉSUMÉ\nLANGUE: ${language.toUpperCase()}\n\nRésume le texte suivant:\n\n---\n${textToSummarize}\n---`;
    await streamMessage(prompt);
  }, [language, streamMessage]);

  if (isLoadingIndex) {
    return <FullPageLoader message={error} />;
  }

  return (
    <div className="flex h-screen w-full text-slate-200 bg-slate-900">
      <Sidebar 
        nodes={sefariaTree} 
        onSelectRef={handleSelectRef} 
        activeRef={activeRef}
        language={language}
      />
      <main className="flex flex-col flex-1 h-screen bg-slate-850">
        <Header language={language} onLanguageChange={handleLanguageChange} />
        <ChatView messages={messages} onSummarize={handleSummarize} />
        <InputArea onSendMessage={handleSendMessage} isSending={isSending} language={language} />
      </main>
    </div>
  );
};

export default App;